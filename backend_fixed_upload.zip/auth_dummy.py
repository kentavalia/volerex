class User:
    pass

def get_authorized_user():
    return User()
